<?php

/**
 * Test file to see raw Gemini response
 * Open this in browser: http://localhost/ToneBridge/test_gemini.php
 */

// Gemini API configuration
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');
$apiKey = 'AIzaSyCO-LhlOYVfHJZlLaZwC7H8rKFa7mBZL2U';
$apiUrl = GEMINI_API_ENDPOINT . '?key=' . $apiKey;

$testMessage = "I love you and you don't love me why?";

$prompt = "You are a HUMAN INTERACTION MEDIATOR. Your role is to analyze messages and rewrite them to reduce emotional friction, misunderstandings, and unintended harshness while preserving the original intent.

Analyze this message and provide your response in EXACTLY this format:

Tone Detected:
- Tone: <short label>
- Risk Level: <Low | Medium | High>
- Reason: <1-2 sentences explaining why this message may be misinterpreted>

Rewritten Messages:
1. Calm & Friendly:
<rewritten message>
Why this works: <1 sentence>

2. Professional & Clear:
<rewritten message>
Why this works: <1 sentence>

3. Empathetic & Supportive:
<rewritten message>
Why this works: <1 sentence>

IMPORTANT RULES:
- Preserve the original intent completely
- Reduce defensiveness and improve clarity
- Avoid robotic or overly polite tone
- Do not judge or shame the sender
- Do not introduce new information
- Keep rewrites natural and human

Message to analyze:
\"$testMessage\"";

$requestData = [
    'contents' => [
        [
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ],
    'generationConfig' => [
        'temperature' => 0.7,
        'topK' => 40,
        'topP' => 0.95,
        'maxOutputTokens' => 1024,
    ]
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$responseData = json_decode($response, true);

if (isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
    $aiResponse = $responseData['candidates'][0]['content']['parts'][0]['text'];

    echo "<h1>Raw Gemini Response:</h1>";
    echo "<pre style='background:#f5f5f5; padding:20px; border:1px solid #ddd;'>";
    echo htmlspecialchars($aiResponse);
    echo "</pre>";

    echo "<h2>Parsed Result:</h2>";
    require_once 'process.php';
    $parsed = parseGeminiResponse($aiResponse);
    echo "<pre style='background:#f5f5f5; padding:20px; border:1px solid #ddd;'>";
    print_r($parsed);
    echo "</pre>";
} else {
    echo "<h1>Error:</h1>";
    echo "<pre>";
    print_r($responseData);
    echo "</pre>";
}
