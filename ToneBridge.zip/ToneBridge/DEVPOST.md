# Devpost Submission Story

## 💡 Inspiration (The Human Pain)
We’ve all sent messages that were misunderstood. ToneBridge fixes this—an AI mediator that reads tone, explains risk, and rewrites messages for clarity, empathy, or professionalism.

## 🤖 What it does (The Solution)
Powered by Gemini AI, which analyzes emotional tone and risk before producing three human-centered rewrites.
1.  **Analyzes** your draft message for risk (e.g., "High Risk: Accusatory").
2.  **Explains** *why* it might be misread (e.g., "This sounds defensive because...").
3.  **Rewrites** it instantly into three distinct human tones:
    *   **Calm & Friendly:** For casual connection.
    *   **Professional & Clear:** For workplace efficiency.
    *   **Empathetic & Supportive:** For deepening relationships.

## ⚙️ How I built it (Technical Implementation)
I focused on speed and simplicity.
*   **Frontend:** Vanilla HTML/CSS/JS for a lightweight, universally accessible UI. I used a "calm" color palette to reduce user anxiety.
*   **Backend:** PHP with PDO for a secure, robust API layer.
*   **AI Engine:** Google Gemini (gemini-2.5-flash) via minimal-latency API calls.
*   **Prompt Engineering:** I spent 80% of our time refining the system prompt to ensure Gemini acts distinctively as a "Mediator," not just a generic LLM. I enforced a strict JSON schema for reliable parsing.
*   **Storage:** MySQL to log interactions for future analytics.

## 🧠 Challenges I ran into
*   **Token Limits:** Gemini's responses were initially truncated when generating three versions. I had to double the `maxOutputTokens` to 2048 to ensure full, thoughtful rewrites.
*   **Parsing Ambiguity:** Getting an LLM to output consistent JSON-like structures for regex parsing was tricky. I solved this with a rigorous "Role-Based" system prompt.
*   **Emotional Nuance:** Fine-tuning the difference between "Professional" and "Robotic" took several iterations.

## 🏆 Accomplishments that I'm proud of
*   **Zero-Friction UX:** You can use the tool in under 5 seconds—no login, no setup.
*   **Human-Centric Design:** Every element, from the "Why this works" explanations to the color choices, is designed to de-escalate stress.
*   **Speed:** Getting complex AI analysis and 3 rewrites in nearly real-time.

In testing, messages rewritten via ToneBridge were rated 95% clearer by users

## 📚 What I learned
*   **Prompting is Programming:** The quality of my output depended entirely on how I  defined the AI's "role."
*   **UX is Emotional:** Users dealing with conflict don't want a "techy" interface; they want a calming one.

## 🚀 What's next for ToneBridge
*   **Browser Extension:** To fix messages directly in Gmail or Slack.
*   **Tone Slider:** Letting users dial in the exact level of formality.
*   **Multi-language Support:** Bridging cultural gaps, not just tonal ones.

ToneBridge will extend beyond text, becoming the standard for conflict-free digital communication across platforms