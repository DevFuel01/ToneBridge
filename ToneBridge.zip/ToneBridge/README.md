# ToneBridge – Human-Aware Message Rewriter

> **Improve human interaction by rewriting messages to reduce emotional friction, misunderstandings, and unintended harshness.**

ToneBridge is a web application that uses **Gemini AI** to analyze the emotional tone of messages and provide human-aware rewrites that preserve intent while improving clarity and emotional safety.

---

## 🎯 What ToneBridge Does

ToneBridge acts as a **Human Interaction Mediator** that:

1. **Analyzes** your message for emotional tone and misunderstanding risk
2. **Detects** potential friction points that could harm relationships
3. **Rewrites** your message in three different tones:
   - **Calm & Friendly** – Warm and approachable
   - **Professional & Clear** – Formal and unambiguous
   - **Empathetic & Supportive** – Compassionate and understanding
4. **Preserves** your original intent while reducing defensiveness
5. **Logs** interactions for future improvement and analytics

---

## 🧠 How Gemini AI is Used

ToneBridge leverages **Google's Gemini AI** as a sophisticated tone analyzer and message rewriter:

### AI Behavior
- Acts as a **non-judgmental mediator** between humans
- Preserves the sender's original intent
- Reduces emotional friction without being robotic
- Provides explanations for why messages may be misinterpreted
- Offers practical alternatives that feel natural and human

### Structured Output
Gemini is prompted to return responses in a consistent format:
```
Tone Detected:
- Tone: <label>
- Risk Level: Low | Medium | High
- Reason: <explanation>

Rewritten Messages:
1. Calm & Friendly: <message> + Why this works
2. Professional & Clear: <message> + Why this works
3. Empathetic & Supportive: <message> + Why this works
```

This ensures reliable parsing and a consistent user experience.

---

## 🚀 Features

✅ **Real-time Tone Analysis** – Instant feedback on emotional tone  
✅ **Risk Level Detection** – Understand potential misinterpretation  
✅ **Three Rewrite Options** – Choose the tone that fits your context  
✅ **Before/After Comparison** – See the transformation side-by-side  
✅ **One-Click Copy** – Easily use the improved message  
✅ **Database Logging** – Track interactions for insights  
✅ **Mobile Responsive** – Works on all devices  
✅ **Clean UI** – Calm, trustworthy, and non-aggressive design  

---

## 🛠️ Technology Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | HTML5, CSS3, Vanilla JavaScript |
| **Backend** | PHP 7.4+ with PDO |
| **Database** | MySQL 5.7+ |
| **AI** | Google Gemini AI (gemini-pro) |
| **Security** | Prepared statements, input sanitization |

---

## 📦 Installation & Setup

### Prerequisites
- **XAMPP** (or any PHP + MySQL environment)
- **Gemini API Key** ([Get one here](https://makersuite.google.com/app/apikey))

### Step 1: Clone/Download the Project
```bash
# Place the ToneBridge folder in your htdocs directory
C:\xampp\htdocs\ToneBridge
```

### Step 2: Set Up the Database
1. Start **XAMPP** and run **Apache** and **MySQL**
2. Open **phpMyAdmin** (http://localhost/phpmyadmin)
3. Import the database:
   ```sql
   # Run the contents of database.sql
   # This creates the tonebridge_db database and message_logs table
   ```

**OR** run this SQL directly:
```sql
CREATE DATABASE IF NOT EXISTS tonebridge_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE tonebridge_db;

CREATE TABLE IF NOT EXISTS message_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    original_message TEXT NOT NULL,
    detected_tone VARCHAR(100),
    risk_level VARCHAR(20),
    selected_version VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at),
    INDEX idx_risk_level (risk_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### Step 3: Configure Gemini API Key
1. Open `process.php`
2. Find this line:
   ```php
   $apiKey = 'YOUR_GEMINI_API_KEY_HERE';
   ```
3. Replace with your actual Gemini API key:
   ```php
   $apiKey = 'AIzaSyC...your-actual-key';
   ```

### Step 4: Run the Application
1. Navigate to: **http://localhost/ToneBridge**
2. Enter a message and click **"Analyze & Rewrite"**
3. Choose your preferred tone and copy the improved message

---

## 📖 How to Use

### Example Workflow

**Original Message:**
> "I told you this already. Why aren't you listening?"

**ToneBridge Analysis:**
- **Tone:** Frustrated, Accusatory
- **Risk Level:** High
- **Reason:** May make the recipient defensive and damage trust

**Rewritten Options:**

1. **Calm & Friendly:**  
   *"I think I mentioned this before – want me to clarify again?"*  
   → Opens dialogue without blame

2. **Professional & Clear:**  
   *"I shared this information previously. Would you like me to resend it?"*  
   → Maintains professionalism while being direct

3. **Empathetic & Supportive:**  
   *"I know things get busy! Let me share this again to make sure we're aligned."*  
   → Acknowledges context and reduces friction

---

## 🎨 Design Philosophy

ToneBridge is designed to feel:
- **Calm** – Soft colors, generous spacing
- **Human** – Natural language, no corporate jargon
- **Trustworthy** – Clear explanations, no hidden agenda
- **Non-aggressive** – Supportive tone, never judgmental

---

## 🔒 Security Features

- ✅ **Prepared Statements** – Prevents SQL injection
- ✅ **Input Sanitization** – Validates all user input
- ✅ **Error Logging** – Secure error handling (no sensitive data exposed)
- ✅ **API Key Protection** – Never exposed to frontend
- ✅ **HTTPS Ready** – Works with SSL in production

---

## 📊 Database Schema

### `message_logs` Table
| Column | Type | Description |
|--------|------|-------------|
| `id` | INT | Primary key (auto-increment) |
| `original_message` | TEXT | User's original message |
| `detected_tone` | VARCHAR(100) | AI-detected tone |
| `risk_level` | VARCHAR(20) | Low, Medium, or High |
| `selected_version` | VARCHAR(50) | User's chosen rewrite |
| `created_at` | TIMESTAMP | When the interaction occurred |

---

## 🎯 Hackathon Demo Script (Under 2 Minutes)

### Introduction (15 seconds)
*"ToneBridge improves human interaction by rewriting messages to reduce emotional friction. It uses Gemini AI to analyze tone and suggest better alternatives."*

### Live Demo (60 seconds)
1. **Show a harsh message:**  
   *"This is wrong. Fix it now."*
   
2. **Click Analyze & Rewrite**  
   Show the tone analysis (Aggressive, High Risk)

3. **Display three rewrites:**
   - Calm & Friendly
   - Professional & Clear
   - Empathetic & Supportive

4. **Select one and copy it**  
   Show the before/after comparison

### Technical Highlights (30 seconds)
- **Gemini AI** for intelligent tone analysis
- **Structured prompts** ensure consistent output
- **MySQL logging** for scalability
- **Clean PHP backend** with PDO security

### Impact Statement (15 seconds)
*"ToneBridge helps people communicate better, reducing conflict and building trust – one message at a time."*

---

## 🚧 Future Enhancements

- 🔄 **Tone customization** (adjust formality level)
- 📧 **Email integration** (Gmail, Outlook plugins)
- 📊 **Analytics dashboard** (track tone trends)
- 🌍 **Multi-language support**
- 🤖 **Slack/Teams integration**

---

## 📄 License

This project is open-source and available for educational and hackathon purposes.

---

## 🙏 Acknowledgments

- **Google Gemini AI** for powering the intelligence
- **XAMPP** for local development environment
- **The hackathon community** for inspiring better human interaction

---

## 📧 Contact

email: [Ibrahimi107809@gmail.com]
phone number: +234 7062616249
Built with ❤️ for better human interaction.

**Demo it. Use it. Improve it.**

---

### Quick Start Checklist
- [ ] XAMPP installed and running
- [ ] Database created (`tonebridge_db`)
- [ ] Gemini API key added to `process.php`
- [ ] Navigate to `http://localhost/ToneBridge`
- [ ] Test with a sample message
- [ ] Ready to demo! 🎉
