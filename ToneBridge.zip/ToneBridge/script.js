/**
 * ToneBridge - Frontend JavaScript
 * Handles user interactions and API communication
 */

// DOM Elements
const messageInput = document.getElementById('messageInput');
const charCount = document.getElementById('charCount');
const analyzeBtn = document.getElementById('analyzeBtn');
const loadingState = document.getElementById('loadingState');
const resultsSection = document.getElementById('resultsSection');
const copyBtn = document.getElementById('copyBtn');
const newMessageBtn = document.getElementById('newMessageBtn');

// Result elements
const detectedTone = document.getElementById('detectedTone');
const riskLevel = document.getElementById('riskLevel');
const riskReason = document.getElementById('riskReason');
const originalMessage = document.getElementById('originalMessage');
const improvedMessage = document.getElementById('improvedMessage');

// Rewrite elements
const calmMessage = document.getElementById('calmMessage');
const calmExplanation = document.getElementById('calmExplanation');
const professionalMessage = document.getElementById('professionalMessage');
const professionalExplanation = document.getElementById('professionalExplanation');
const empatheticMessage = document.getElementById('empatheticMessage');
const empatheticExplanation = document.getElementById('empatheticExplanation');

// State
let currentData = null;
let selectedVersion = null;

// Character counter
messageInput.addEventListener('input', () => {
    const count = messageInput.value.length;
    charCount.textContent = count;
    
    // Enable/disable analyze button
    analyzeBtn.disabled = count === 0;
});

// Analyze button click
analyzeBtn.addEventListener('click', async () => {
    const message = messageInput.value.trim();
    
    if (!message) {
        showError('Please enter a message to analyze');
        return;
    }
    
    // Show loading state
    loadingState.classList.remove('hidden');
    resultsSection.classList.add('hidden');
    analyzeBtn.disabled = true;
    
    try {
        // Call backend API
        const response = await fetch('process.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.error || 'Failed to analyze message');
        }
        
        // Store data and display results
        currentData = result.data;
        displayResults(result.data);
        
    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Something went wrong. Please try again.');
    } finally {
        loadingState.classList.add('hidden');
        analyzeBtn.disabled = false;
    }
});

// Display results
function displayResults(data) {
    // Set tone analysis
    detectedTone.textContent = data.tone;
    
    // Set risk level with appropriate styling
    riskLevel.textContent = data.risk_level;
    riskLevel.className = 'value risk-badge ' + data.risk_level.toLowerCase();
    
    riskReason.textContent = data.reason;
    
    // Set original message
    originalMessage.textContent = data.original_message;
    
    // Set rewritten versions
    
    if (data.rewrites.calm) {
        calmMessage.textContent = data.rewrites.calm.message;
        calmExplanation.textContent = data.rewrites.calm.explanation;
    }
    
    if (data.rewrites.professional) {
        professionalMessage.textContent = data.rewrites.professional.message;
        professionalExplanation.textContent = data.rewrites.professional.explanation;
    }
    
    if (data.rewrites.empathetic) {
        empatheticMessage.textContent = data.rewrites.empathetic.message;
        empatheticExplanation.textContent = data.rewrites.empathetic.explanation;
    }
    
    // Reset selection
    selectedVersion = null;
    improvedMessage.textContent = 'Select a version below';
    copyBtn.disabled = true;
    
    // Remove all selected states
    document.querySelectorAll('.btn-select').forEach(btn => {
        btn.classList.remove('selected');
    });
    
    // Show results
    resultsSection.classList.remove('hidden');
    
    // Smooth scroll to results
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Handle version selection
document.querySelectorAll('.btn-select').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const version = e.target.dataset.version;
        selectVersion(version);
    });
});

// Select a rewritten version
function selectVersion(version) {
    selectedVersion = version;
    
    // Update improved message display
    if (currentData && currentData.rewrites[version]) {
        improvedMessage.textContent = currentData.rewrites[version].message;
    }
    
    // Update button states
    document.querySelectorAll('.btn-select').forEach(btn => {
        if (btn.dataset.version === version) {
            btn.classList.add('selected');
            btn.textContent = '✓ Selected';
        } else {
            btn.classList.remove('selected');
            btn.textContent = 'Use This Version';
        }
    });
    
    // Enable copy button
    copyBtn.disabled = false;
    
    // Smooth scroll to comparison
    document.querySelector('.comparison-card').scrollIntoView({ 
        behavior: 'smooth', 
        block: 'nearest' 
    });
}

// Copy to clipboard
copyBtn.addEventListener('click', async () => {
    if (!selectedVersion || !currentData) return;
    
    const textToCopy = currentData.rewrites[selectedVersion].message;
    
    try {
        await navigator.clipboard.writeText(textToCopy);
        
        // Visual feedback
        const originalText = copyBtn.innerHTML;
        copyBtn.innerHTML = '✓ Copied!';
        copyBtn.style.background = 'var(--success)';
        copyBtn.style.color = 'white';
        
        setTimeout(() => {
            copyBtn.innerHTML = originalText;
            copyBtn.style.background = '';
            copyBtn.style.color = '';
        }, 2000);
        
    } catch (error) {
        console.error('Failed to copy:', error);
        showError('Failed to copy to clipboard');
    }
});

// New message button
newMessageBtn.addEventListener('click', () => {
    // Reset form
    messageInput.value = '';
    charCount.textContent = '0';
    
    // Hide results
    resultsSection.classList.add('hidden');
    
    // Reset state
    currentData = null;
    selectedVersion = null;
    
    // Scroll to top
    messageInput.focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Error handling
function showError(message) {
    // Simple alert for now - could be enhanced with a toast notification
    alert('Error: ' + message);
}

// Allow Enter + Ctrl/Cmd to submit
messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        analyzeBtn.click();
    }
});

// Initialize
analyzeBtn.disabled = true;
