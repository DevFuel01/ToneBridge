# ToneBridge Testing Guide

## Quick Test

1. **Open the application:**
   - Navigate to: http://localhost/ToneBridge

2. **Test with this message:**
   ```
   I love you and you don't love me why?
   ```

3. **Expected Results:**
   - ✅ Tone: Should show something like "Accusatory & Hurt" or similar
   - ✅ Risk Level: Should show "High" or "Medium"
   - ✅ Reason: Should explain why the message may be misinterpreted
   - ✅ Three rewritten versions should appear with actual messages
   - ✅ Each version should have an explanation

## Debugging

If the rewrites still show "-", check the error log:

**XAMPP Error Log Location:**
- `C:\xampp\apache\logs\error.log`

Look for lines starting with:
```
Gemini Raw Response: ...
```

This will show exactly what Gemini is returning, which helps debug parsing issues.

## Common Issues

### Issue: Rewrites show "-"
**Solution:** Check the error log to see the raw Gemini response format

### Issue: "AI service temporarily unavailable"
**Solution:** Verify your API key is correct in `process.php`

### Issue: "Database connection failed"
**Solution:** Make sure MySQL is running in XAMPP Control Panel

## Test Messages

Try these messages to test different tones:

1. **Accusatory:**
   "I told you this already. Why aren't you listening?"

2. **Frustrated:**
   "This is wrong. Fix it now."

3. **Passive-Aggressive:**
   "I guess my opinion doesn't matter here."

4. **Demanding:**
   "Send me the report immediately."

5. **Emotional:**
   "I love you and you don't love me why?"
