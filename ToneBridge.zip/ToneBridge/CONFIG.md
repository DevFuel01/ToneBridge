/**
 * ToneBridge - Configuration Template
 * 
 * IMPORTANT: Before using ToneBridge, you MUST:
 * 1. Get a Gemini API key from: https://makersuite.google.com/app/apikey
 * 2. Replace YOUR_GEMINI_API_KEY_HERE with your actual key in process.php
 * 3. Set up the database using SETUP_DATABASE.md instructions
 */

// ============================================
// GEMINI API CONFIGURATION
// ============================================

// Get your API key here: https://makersuite.google.com/app/apikey
// Then open process.php and replace:
// $apiKey = 'YOUR_GEMINI_API_KEY_HERE';
// with your actual key

// ============================================
// DATABASE CONFIGURATION
// ============================================

// Default XAMPP settings (already configured in db.php):
// Host: localhost
// Database: tonebridge_db
// Username: root
// Password: (empty)

// If you need to change these, edit db.php

// ============================================
// SETUP CHECKLIST
// ============================================

// [ ] 1. XAMPP installed and running (Apache + MySQL)
// [ ] 2. Database created (see SETUP_DATABASE.md)
// [ ] 3. Gemini API key added to process.php
// [ ] 4. Navigate to http://localhost/ToneBridge
// [ ] 5. Test with a sample message
// [ ] 6. Ready to demo!

// ============================================
// TROUBLESHOOTING
// ============================================

// Problem: "Database connection failed"
// Solution: Make sure MySQL is running in XAMPP Control Panel

// Problem: "AI service temporarily unavailable"
// Solution: Check your Gemini API key in process.php

// Problem: Page not loading
// Solution: Make sure Apache is running in XAMPP Control Panel

// Problem: "Invalid response from AI service"
// Solution: Check your internet connection and API key validity
