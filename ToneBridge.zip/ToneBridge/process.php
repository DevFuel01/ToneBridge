<?php

/**
 * ToneBridge - Message Processing Backend
 * Handles Gemini AI integration and database logging
 */

header('Content-Type: application/json');
require_once 'db.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get and sanitize input
$input = json_decode(file_get_contents('php://input'), true);
$originalMessage = trim($input['message'] ?? '');

// Validate input
if (empty($originalMessage)) {
    echo json_encode(['success' => false, 'error' => 'Message cannot be empty']);
    exit;
}

if (strlen($originalMessage) > 5000) {
    echo json_encode(['success' => false, 'error' => 'Message too long (max 5000 characters)']);
    exit;
}

// Gemini API configuration
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');
$apiKey = ''; // Replace with your actual API key
$apiUrl = GEMINI_API_ENDPOINT . '?key=' . $apiKey;

// Construct the prompt for Gemini
$prompt = "You are a HUMAN INTERACTION MEDIATOR. Your role is to analyze messages and rewrite them to reduce emotional friction, misunderstandings, and unintended harshness while preserving the original intent.

Analyze this message and provide your response in EXACTLY this format:

Tone Detected:
- Tone: <short label>
- Risk Level: <Low | Medium | High>
- Reason: <1-2 sentences explaining why this message may be misinterpreted>

Rewritten Messages:
1. Calm & Friendly:
<rewritten message>
Why this works: <1 sentence>

2. Professional & Clear:
<rewritten message>
Why this works: <1 sentence>

3. Empathetic & Supportive:
<rewritten message>
Why this works: <1 sentence>

IMPORTANT RULES:
- Preserve the original intent completely
- Reduce defensiveness and improve clarity
- Avoid robotic or overly polite tone
- Do not judge or shame the sender
- Do not introduce new information
- Keep rewrites natural and human

Message to analyze:
\"$originalMessage\"";

// Prepare Gemini API request
$requestData = [
    'contents' => [
        [
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ],
    'generationConfig' => [
        'temperature' => 0.7,
        'topK' => 40,
        'topP' => 0.95,
        'maxOutputTokens' => 2048,
    ]
];

// Make API request to Gemini
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Handle API errors
if ($httpCode !== 200) {
    error_log("Gemini API Error: " . $response);
    echo json_encode([
        'success' => false,
        'error' => 'AI service temporarily unavailable. Please try again.'
    ]);
    exit;
}

$responseData = json_decode($response, true);

// Extract AI response
if (!isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid response from AI service'
    ]);
    exit;
}

$aiResponse = $responseData['candidates'][0]['content']['parts'][0]['text'];

// Parse the AI response
$parsedResponse = parseGeminiResponse($aiResponse);

// Save to database
try {
    $stmt = $pdo->prepare("
        INSERT INTO message_logs (original_message, detected_tone, risk_level, selected_version)
        VALUES (:original_message, :detected_tone, :risk_level, :selected_version)
    ");

    $stmt->execute([
        ':original_message' => $originalMessage,
        ':detected_tone' => $parsedResponse['tone'],
        ':risk_level' => $parsedResponse['risk_level'],
        ':selected_version' => 'none' // Will be updated when user selects a version
    ]);

    $logId = $pdo->lastInsertId();
} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    // Continue even if logging fails - user experience is priority
}

// Return successful response
echo json_encode([
    'success' => true,
    'data' => [
        'original_message' => $originalMessage,
        'tone' => $parsedResponse['tone'],
        'risk_level' => $parsedResponse['risk_level'],
        'reason' => $parsedResponse['reason'],
        'rewrites' => $parsedResponse['rewrites'],
        'log_id' => $logId ?? null
    ]
]);

/**
 * Parse Gemini's structured response
 */
function parseGeminiResponse($response)
{
    $result = [
        'tone' => 'Unknown',
        'risk_level' => 'Medium',
        'reason' => 'Unable to analyze',
        'rewrites' => []
    ];

    // Extract tone
    if (preg_match('/- Tone:\s*(.+)/i', $response, $matches)) {
        $result['tone'] = trim($matches[1]);
    }

    // Extract risk level
    if (preg_match('/- Risk Level:\s*(Low|Medium|High)/i', $response, $matches)) {
        $result['risk_level'] = trim($matches[1]);
    }

    // Extract reason - improved pattern
    if (preg_match('/- Reason:\s*(.+?)(?=\n\s*\n|Rewritten Messages:|$)/si', $response, $matches)) {
        $result['reason'] = trim($matches[1]);
    }

    // Extract Calm & Friendly
    if (preg_match('/1\.\s*Calm\s*&\s*Friendly:\s*\n?\s*(.+?)\s*\n?\s*Why this works:\s*(.+?)(?=\n\s*\n|2\.|$)/si', $response, $matches)) {
        $result['rewrites']['calm'] = [
            'message' => trim($matches[1]),
            'explanation' => trim($matches[2])
        ];
    }

    // Extract Professional & Clear
    if (preg_match('/2\.\s*Professional\s*&\s*Clear:\s*\n?\s*(.+?)\s*\n?\s*Why this works:\s*(.+?)(?=\n\s*\n|3\.|$)/si', $response, $matches)) {
        $result['rewrites']['professional'] = [
            'message' => trim($matches[1]),
            'explanation' => trim($matches[2])
        ];
    }

    // Extract Empathetic & Supportive
    if (preg_match('/3\.\s*Empathetic\s*&\s*Supportive:\s*\n?\s*(.+?)\s*\n?\s*Why this works:\s*(.+?)$/si', $response, $matches)) {
        $result['rewrites']['empathetic'] = [
            'message' => trim($matches[1]),
            'explanation' => trim($matches[2])
        ];
    }

    return $result;
}
