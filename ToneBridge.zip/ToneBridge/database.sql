-- ToneBridge Database Schema
-- Human-Aware Message Rewriter

CREATE DATABASE IF NOT EXISTS tonebridge_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE tonebridge_db;

-- Message logs table to track all interactions
CREATE TABLE IF NOT EXISTS message_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    original_message TEXT NOT NULL,
    detected_tone VARCHAR(100),
    risk_level VARCHAR(20),
    selected_version VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at),
    INDEX idx_risk_level (risk_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
