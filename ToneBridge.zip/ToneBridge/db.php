<?php
/**
 * ToneBridge - Database Connection
 * Secure PDO connection with error handling
 */

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'tonebridge_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Create PDO connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    // Log error securely (in production, log to file instead of displaying)
    error_log("Database Connection Error: " . $e->getMessage());
    die(json_encode([
        'success' => false,
        'error' => 'Database connection failed. Please try again later.'
    ]));
}
