-- ============================================
-- ToneBridge Database Setup Instructions
-- ============================================

-- OPTION 1: Using phpMyAdmin (Recommended)
-- 1. Open http://localhost/phpmyadmin
-- 2. Click "SQL" tab
-- 3. Copy and paste the SQL below
-- 4. Click "Go"

-- OPTION 2: Using MySQL Command Line
-- 1. Open XAMPP Control Panel
-- 2. Click "Shell" button
-- 3. Run: mysql -u root
-- 4. Copy and paste the SQL below

-- ============================================
-- SQL COMMANDS
-- ============================================

CREATE DATABASE IF NOT EXISTS tonebridge_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE tonebridge_db;

CREATE TABLE IF NOT EXISTS message_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    original_message TEXT NOT NULL,
    detected_tone VARCHAR(100),
    risk_level VARCHAR(20),
    selected_version VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at),
    INDEX idx_risk_level (risk_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- VERIFY INSTALLATION
-- ============================================

-- Run this to verify the table was created:
SHOW TABLES;
DESCRIBE message_logs;

-- You should see the message_logs table with all columns
